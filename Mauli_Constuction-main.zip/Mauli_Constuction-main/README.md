# Mauli_Constuction
1.Developed an Mauli construction website as a part of a team project during my academic studies.
2.The website allows users have seen what work done mauli constuction did.
3.Utilized HTML, CSS, and Bootstrap for the frontend development.
4.In Navbar section I create six navlink. In home section one mauli quotes with good background 
image of construction.In about section who is director of mauli consruction is provide.In What we 
do section- what is the benefits to give mauli construction.eg.seamless communication, budgeting, 
staffing, on-site organization, and solid, quality handiwork every time.In our section what mauli 
construction do-home construction,industrail,compound wall,etc.In services section -
preconstuction, construction, postconstruction topics.In contact us we provide mob.no also register 
form provide for user
